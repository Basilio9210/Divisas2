﻿
# AdMobView

Don't forget to add the following to your Android.Manifest inside <application>:

<activity android:name="com.google.android.gms.ads.AdActivity" 
		  android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize" />